import React, { useEffect, useState } from 'react';
import { getAllPosts, deletePost } from '../services/api';
import { useAuth } from '../context/AuthContext';
import CreatePostModal from '../components/CreatePostModal';
import EditPostModal from '../components/EditPostModal';

const HomePage = () => {
  const { currentUser } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editingPost, setEditingPost] = useState(null);
  const [sortBy, setSortBy] = useState('date');

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const { data } = await getAllPosts();
        setPosts(data);
      } catch (err) {
        console.error(err);
        setError('Failed to fetch posts.');
      } finally {
        setLoading(false);
      }
    };
    fetchPosts();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this post?')) return;
    try {
      await deletePost(id);
      setPosts(posts.filter((p) => p._id !== id));
    } catch (err) {
      console.error(err);
      setError('Failed to delete post.');
    }
  };

  const handleEdit = (post) => setEditingPost(post);
  const handleCloseEdit = () => setEditingPost(null);

  const handlePostCreated = (newPost) => setPosts([newPost, ...posts]);
  const handlePostUpdated = (updatedPost) =>
    setPosts(posts.map((p) => (p._id === updatedPost._id ? updatedPost : p)));

  const sortedPosts = [...posts].sort((a, b) => {
    if (sortBy === 'price') return (a.price || 0) - (b.price || 0);
    return new Date(b.createdAt) - new Date(a.createdAt);
  });

  if (loading)
    return (
      <div className="flex items-center justify-center h-screen">
        <span className="loading loading-spinner loading-lg text-primary"></span>
      </div>
    );

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-blue-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
          <h1 className="text-3xl font-bold text-gray-800 drop-shadow-sm">
            Yu-Gi-Oh! Marketplace
          </h1>
          <div className="flex gap-3">
            <button
              className="btn btn-primary shadow-md"
              onClick={() =>
                document.getElementById('create_post_modal').showModal()
              }
            >
              + New Post
            </button>

            <select
              className="select select-bordered"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="date">Sort by Date</option>
              <option value="price">Sort by Price</option>
            </select>
          </div>
        </div>

        {/* Error */}
        {error && (
          <p className="text-center text-red-500 mb-4 font-medium">{error}</p>
        )}

        {/* Post Grid */}
        {sortedPosts.length === 0 ? (
          <p className="text-center text-gray-500 italic mt-10">
            No posts yet. Be the first to create one!
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {sortedPosts.map((post) => (
              <div
                key={post._id}
                className="card bg-base-100 shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 border border-base-300"
              >
                <figure className="bg-gradient-to-br from-indigo-500 to-purple-600 p-4">
                  <img
                    src={post.cardImageUrl || '/placeholder-card.png'}
                    alt={post.cardName}
                    className="rounded-xl w-full object-contain h-48"
                  />
                </figure>

                <div className="card-body">
                  <h2 className="card-title text-lg font-semibold text-gray-800">
                    {post.cardName}
                  </h2>
                  <p className="text-sm text-gray-600">
                    <span className="font-semibold">
                      {post.postType === 'buy' ? 'Buying' : 'Selling'}
                    </span>{' '}
                    • {post.condition}
                  </p>

                  {post.price && (
                    <p className="text-primary font-bold text-lg mt-2">
                      {post.price} ₪
                    </p>
                  )}

                  <div className="card-actions justify-end mt-3">
                    {currentUser?.email === post.contactEmail && (
                      <>
                        <button
                          className="btn btn-sm btn-outline btn-primary"
                          onClick={() => handleEdit(post)}
                        >
                          Edit
                        </button>
                        <button
                          className="btn btn-sm btn-outline btn-error"
                          onClick={() => handleDelete(post._id)}
                        >
                          Delete
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modals */}
      <CreatePostModal onPostCreated={handlePostCreated} />
      {editingPost && (
        <EditPostModal
          post={editingPost}
          onClose={handleCloseEdit}
          onUpdate={handlePostUpdated}
        />
      )}
    </div>
  );
};

export default HomePage;
